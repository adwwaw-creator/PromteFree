# ArabiPrompt Private Analytics — Integration

This is a starter integration, not a deployed analytics service. It records page views and approximate unique browser IDs, not actual identified people. The admin page is deliberately NOT published on GitHub Pages.

## Deploy Worker and database
1. `cd worker && npm install && npx wrangler login`
2. `npx wrangler d1 create arabiprompt-analytics`; copy the resulting database ID to `wrangler.toml`.
3. Set `ALLOWED_ORIGIN` to your exact public site origin (scheme + hostname, no trailing slash).
4. `npm run db:migrate && npm run deploy`.
5. Add a Cloudflare Access self-hosted application for `https://YOUR_WORKER_DOMAIN/api/*`, restricted to your own email. Copy the application's AUD and team name to the Worker config; redeploy.
6. IMPORTANT: also protect the entire admin dashboard hostname with Access. This code checks Access JWT signatures for `/api/stats`, but the dashboard itself must only be hosted behind Access.

## Site integration
Copy `dashboard/src/VisitorTracker.tsx` into your Vite React source folder. Mount `<VisitorTracker />` once inside your existing App. Set `VITE_ANALYTICS_URL` to the deployed Worker origin in the Vite build environment. Do not place secrets in VITE_ variables.

## Private dashboard
Host `dashboard/src/AdminAnalytics.tsx` in a separate React/Vite site on Cloudflare Pages behind Cloudflare Access. Route `/api/stats` from the admin hostname to the Worker (via a Pages Function proxy or Worker route). The component uses a relative `/api/stats` request and requires this routing. Do not publish the dashboard at a public GitHub Pages route. Cloudflare Access must guard the private host and API.

## Production limitations
- Origin checks are not authentication or anti-bot protection. Add WAF/rate limiting and bot filtering in Cloudflare.
- Geographic data from Cloudflare request metadata may be missing or approximate.
- Visitor UUIDs stored in localStorage are approximate and can change when storage is cleared. Tracking may require consent depending on applicable law.
- A new visitor ID is stored in browser localStorage and sent to the Worker. Implement a consent gate before mounting the tracker wherever required.
- `visitor_days` accumulates IDs indefinitely until you configure retention. Add a scheduled cleanup job for your retention policy; avoid deleting data before approval.
- For real deployment, configure analytics collection CORS to the actual site origin and ensure Cloudflare Access is correctly enforcing the admin host.
- This is a scaffold; test against your actual project and Cloudflare configuration before production use.
