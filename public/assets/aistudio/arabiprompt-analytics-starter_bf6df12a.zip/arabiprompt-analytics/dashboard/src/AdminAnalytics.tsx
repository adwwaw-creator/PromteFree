import {useEffect,useState} from 'react';
type Location={country:string;city:string;views:number};
type Day={day:string;views:number};
type Stats={days:number;views:number;uniqueVisitors:number;locations:Location[];series:Day[]};
export function AdminAnalytics(){
 const [days,setDays]=useState(7);const [data,setData]=useState<Stats|null>(null);const [error,setError]=useState('');
 useEffect(()=>{const c=new AbortController();setData(null);setError('');
 fetch(`/api/stats?days=${days}`,{signal:c.signal,credentials:'same-origin'}).then(r=>{if(!r.ok)throw Error(`HTTP ${r.status}`);return r.json()}).then(setData).catch(e=>{if(e.name!=='AbortError')setError('Unable to load analytics')});return()=>c.abort()},[days]);
 return <main dir="rtl" style={{maxWidth:960,margin:'auto',padding:24,fontFamily:'system-ui'}}>
 <h1>إحصائيات ArabiPrompt — المدير</h1><label>الفترة: <select value={days} onChange={e=>setDays(Number(e.target.value))}><option value={1}>اليوم</option><option value={7}>7 أيام</option><option value={30}>30 يوماً</option></select></label>
 {error&&<p role="alert">{error}</p>}{!data&&!error&&<p>جار تحميل الإحصائيات...</p>}
 {data&&<><section><h2>مشاهدات الصفحات: {data.views}</h2><h2>زوار فريدون تقريبياً: {data.uniqueVisitors}</h2></section>
 <h2>الزيارات اليومية</h2><table><thead><tr><th>التاريخ</th><th>المشاهدات</th></tr></thead><tbody>{data.series.map(x=><tr key={x.day}><td>{x.day}</td><td>{x.views}</td></tr>)}</tbody></table>
 <h2>مواقع الزوار</h2><table><thead><tr><th>الدولة</th><th>المدينة</th><th>المشاهدات</th></tr></thead><tbody>{data.locations.map((x,i)=><tr key={i}><td>{x.country}</td><td>{x.city}</td><td>{x.views}</td></tr>)}</tbody></table></>}
 </main>;
}
