import { useEffect } from 'react';
export function VisitorTracker() {
  useEffect(() => {
    if (navigator.doNotTrack === '1' || !import.meta.env.VITE_ANALYTICS_URL) return;
    const key='arabiprompt_visitor_id';
    let visitor=localStorage.getItem(key);
    if (!visitor) {visitor=crypto.randomUUID();localStorage.setItem(key,visitor);}
    fetch(`${import.meta.env.VITE_ANALYTICS_URL}/collect`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({visitor}),keepalive:true}).catch(()=>{});
  },[]);
  return null;
}
