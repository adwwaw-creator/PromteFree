CREATE TABLE IF NOT EXISTS daily_stats (day TEXT NOT NULL, country TEXT NOT NULL, city TEXT NOT NULL, views INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(day,country,city));
CREATE TABLE IF NOT EXISTS visitor_days (day TEXT NOT NULL, visitor TEXT NOT NULL, PRIMARY KEY(day,visitor));
CREATE INDEX IF NOT EXISTS idx_daily_day ON daily_stats(day);
