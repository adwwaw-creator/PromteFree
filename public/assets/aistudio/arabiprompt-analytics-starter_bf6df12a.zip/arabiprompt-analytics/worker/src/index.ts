interface Env { DB: D1Database; ALLOWED_ORIGIN: string; ACCESS_AUD: string; ACCESS_TEAM: string; }
const json = (data: unknown, status = 200, headers: Record<string,string> = {}) => new Response(JSON.stringify(data), {status,headers:{'content-type':'application/json; charset=utf-8','cache-control':'no-store',...headers}});
function cors(origin: string, env: Env): Record<string,string> {return origin === env.ALLOWED_ORIGIN ? {'access-control-allow-origin':origin,'vary':'Origin'} : {};}
function b64url(input: string) {return Uint8Array.from(atob(input.replace(/-/g,'+').replace(/_/g,'/').padEnd(Math.ceil(input.length/4)*4,'=')), c=>c.charCodeAt(0));}
async function verifyAccess(request: Request, env: Env): Promise<boolean> {
  const token = request.headers.get('Cf-Access-Jwt-Assertion');
  if (!token || !env.ACCESS_AUD || !env.ACCESS_TEAM) return false;
  try {
    const [head,body,sig] = token.split('.'); if (!head||!body||!sig) return false;
    const header = JSON.parse(new TextDecoder().decode(b64url(head)));
    const payload = JSON.parse(new TextDecoder().decode(b64url(body)));
    if (header.alg !== 'RS256' || typeof header.kid !== 'string' || payload.aud?.includes(env.ACCESS_AUD) !== true || payload.iss !== `https://${env.ACCESS_TEAM}.cloudflareaccess.com` || payload.exp * 1000 <= Date.now()) return false;
    const response = await fetch(`https://${env.ACCESS_TEAM}.cloudflareaccess.com/cdn-cgi/access/certs`);
    if (!response.ok) return false;
    const keys = await response.json() as {keys: JsonWebKey[]};
    const jwk = keys.keys.find(k => k.kid === header.kid); if (!jwk) return false;
    const key = await crypto.subtle.importKey('jwk',jwk,{name:'RSASSA-PKCS1-v1_5',hash:'SHA-256'},false,['verify']);
    return await crypto.subtle.verify('RSASSA-PKCS1-v1_5',key,b64url(sig),new TextEncoder().encode(`${head}.${body}`));
  } catch {return false;}
}
export default {async fetch(request: Request, env: Env): Promise<Response> {
  const url = new URL(request.url), origin = request.headers.get('Origin') || '';
  const headers = cors(origin,env);
  if (request.method === 'OPTIONS' && url.pathname === '/collect') return new Response(null,{status:204,headers:{...headers,'access-control-allow-methods':'POST, OPTIONS','access-control-allow-headers':'Content-Type','access-control-max-age':'86400'}});
  if (url.pathname === '/collect') {
    if (request.method !== 'POST') return json({error:'Method not allowed'},405,headers);
    if (origin !== env.ALLOWED_ORIGIN) return json({error:'Origin not allowed'},403,headers);
    if (Number(request.headers.get('content-length') || 0) > 1024) return json({error:'Too large'},413,headers);
    let body: unknown; try {body=await request.json();}catch{return json({error:'Invalid JSON'},400,headers);}
    if (!body || typeof body !== 'object') return json({error:'Invalid body'},400,headers);
    const v=body as Record<string,unknown>;
    if (typeof v.visitor !== 'string' || !/^[a-f0-9-]{36}$/.test(v.visitor)) return json({error:'Invalid visitor'},400,headers);
    const day=new Date().toISOString().slice(0,10);
    const cf=request.cf as {country?:string;city?:string}|undefined;
    const clean=(x:unknown,n:number)=>typeof x==='string'?x.slice(0,n).replace(/[<>]/g,''):'Unknown';
    const country=clean(cf?.country,2), city=clean(cf?.city,80);
    try {
      await env.DB.batch([
        env.DB.prepare('INSERT INTO daily_stats(day,country,city,views) VALUES(?,?,?,1) ON CONFLICT(day,country,city) DO UPDATE SET views=views+1').bind(day,country,city),
        env.DB.prepare('INSERT OR IGNORE INTO visitor_days(day,visitor) VALUES(?,?)').bind(day,v.visitor)
      ]);
      return json({ok:true},200,headers);
    } catch {return json({error:'Service unavailable'},503,headers);}
  }
  if (url.pathname === '/api/stats') {
    if (request.method !== 'GET') return json({error:'Method not allowed'},405);
    if (!await verifyAccess(request,env)) return json({error:'Unauthorized'},401);
    const days=Math.min(30,Math.max(1,Number(url.searchParams.get('days'))||7));
    const start=new Date(Date.now()-(days-1)*86400000).toISOString().slice(0,10);
    try {
      const [totals,locations,series,unique]=await env.DB.batch([
        env.DB.prepare('SELECT COALESCE(SUM(views),0) AS views FROM daily_stats WHERE day>=?').bind(start),
        env.DB.prepare('SELECT country,city,SUM(views) AS views FROM daily_stats WHERE day>=? GROUP BY country,city ORDER BY views DESC LIMIT 100').bind(start),
        env.DB.prepare('SELECT day,SUM(views) AS views FROM daily_stats WHERE day>=? GROUP BY day ORDER BY day').bind(start),
        env.DB.prepare('SELECT COUNT(DISTINCT visitor) AS visitors FROM visitor_days WHERE day>=?').bind(start)
      ]);
      return json({days,views:totals.results[0]?.views??0,uniqueVisitors:unique.results[0]?.visitors??0,locations:locations.results,series:series.results});
    } catch {return json({error:'Service unavailable'},503);}
  }
  return json({error:'Not found'},404);
}} satisfies ExportedHandler<Env>;
